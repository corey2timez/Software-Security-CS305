package com.snhu.sslserver;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import java.security.MessageDigest;

@RestController
//@RequestMapping("/ssl")
 public class ServerController
  {
   
    /* this method invokes when client sends a HTTP GET request with URL path "/hash" endpoint. */	
     @GetMapping("/hash")
    public String myHash() {
      try{
    	  String name = "Corey Rallings";
    	  MessageDigest md=  MessageDigest.getInstance("SHA-256");
    	  md.update(name.getBytes());
    	  byte[] digest = md.digest();
    	  String hashValue= bytesToHex(digest);
    	  return "Checksum for name :" + name  + "   Hash value  : " + hashValue ;
      }
      catch (Exception e) {
    	  return "Error occured when generating checksum";
      }
    }
    
    /*This is helper method used to convert a byte to array to a hexadecimal string representation. */
    private static String bytesToHex(byte[] bytes)
    {
      StringBuilder sb=new StringBuilder();  // just like String class 
     for(byte b: bytes) {  
    	 sb.append(String.format("%02X",b));
//    	 extracting single bytes from bytes
     }
        //concat each chancter of bytes by converting into hexdecimal form
                   
    return sb.toString();
      
      
    }
  }